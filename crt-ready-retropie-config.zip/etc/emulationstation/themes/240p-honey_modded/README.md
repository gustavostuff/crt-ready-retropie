# 240p-Honey v0.07  April, 8th 2018 by Pietze
Theme for EmulationStation on Retropie/Recalbox with a Pi2Scart / Pi2Jamma device.

LOGO NOTICE:
The used logos and trademarks are copyright of their respective owners.

CREDITS:
Console logos and favorites/allgames/latest icons were copied from alphatoanant’s art book theme. https://retropie.org.uk/forum/topic/11728/theme-art-book/108

Thanks @alphatoanant for the permission to use them!

UPDATES:

- April 8th, 2018: added PC Engine CD
- April 3th, 2018: added Atari2600, sega32x, sfc, Daphne
- October 12th, 2017:	added Arcade, Neo Geo CD and corrected „Neo Geo“
- September 24th, 2017: added SegaCD, NeoGeo, Scumm VM & DoxBox (PC), custom collections
- August 13th, 2017: 	changed logos favorites, last played, allgames,
			polishing console graphics
- August 12th, 2017: 	first release


LOGO NOTICE:
The used logos and trademarks are copyright of their respective owners.

CREDITS:
Console logos and favorites/allgames/latest icons were copied from alphatoanant’s art book theme. https://retropie.org.uk/forum/topic/11728/theme-art-book/108

Thanks @alphatoanant for the permission to use them!
