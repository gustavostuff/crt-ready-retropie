# when exiting an emulator -- revert to 480i NTSC
if tvservice -s | grep -q NTSC; then tvservice -c "NTSC 4:3 P"; fbset -depth 8 -xres 400 -yres 300; fbset -depth 32; fi > /dev/null
