emulationstation #auto
