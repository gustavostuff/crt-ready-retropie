echo fullscreen > /opt/retropie/configs/atarilynx/default; cp /opt/retropie/configs/atarilynx/retroarch_fullscreen.cfg /opt/retropie/configs/atarilynx/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/gamegear/default; cp /opt/retropie/configs/gamegear/retroarch_fullscreen.cfg /opt/retropie/configs/gamegear/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/gb/default; cp /opt/retropie/configs/gb/retroarch_fullscreen.cfg /opt/retropie/configs/gb/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/gba/default; cp /opt/retropie/configs/gba/retroarch_fullscreen.cfg /opt/retropie/configs/gba/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/gbc/default; cp /opt/retropie/configs/gbc/retroarch_fullscreen.cfg /opt/retropie/configs/gbc/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/ngp/default; cp /opt/retropie/configs/ngp/retroarch_fullscreen.cfg /opt/retropie/configs/ngp/retroarch.cfg > /dev/null
echo fullscreen > /opt/retropie/configs/ngpc/default; cp /opt/retropie/configs/ngpc/retroarch_fullscreen.cfg /opt/retropie/configs/ngpc/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/wonderswan/default; cp /opt/retropie/configs/wonderswan/retroarch_pixelperfect.cfg /opt/retropie/configs/wonderswan/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/wonderswancolor/default; cp /opt/retropie/configs/wonderswancolor/retroarch_pixelperfect.cfg /opt/retropie/configs/wonderswancolor/retroarch.cfg > /dev/null
exit 1