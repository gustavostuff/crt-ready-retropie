echo ${4/retroarch.cfg/retroarch_hdmi.cfg} > /tmp/run.sh
bash /tmp/run.sh
exit 1