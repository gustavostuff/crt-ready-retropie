cp /home/pi/RetroPie/BIOS/palettes/DMG.pal /home/pi/RetroPie/BIOS/palettes/default.pal > /dev/null
exit 1