echo pixelperfect > /opt/retropie/configs/atarilynx/default; cp /opt/retropie/configs/atarilynx/retroarch_hdmi.cfg /opt/retropie/configs/atarilynx/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/gamegear/default; cp /opt/retropie/configs/gamegear/retroarch_hdmi.cfg /opt/retropie/configs/gamegear/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/gb/default; cp /opt/retropie/configs/gb/retroarch_hdmi.cfg /opt/retropie/configs/gb/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/gba/default; cp /opt/retropie/configs/gba/retroarch_hdmi.cfg /opt/retropie/configs/gba/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/gbc/default; cp /opt/retropie/configs/gbc/retroarch_hdmi.cfg /opt/retropie/configs/gbc/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/ngp/default; cp /opt/retropie/configs/ngp/retroarch_hdmi.cfg /opt/retropie/configs/ngp/retroarch.cfg > /dev/null
echo pixelperfect > /opt/retropie/configs/ngpc/default; cp /opt/retropie/configs/ngpc/retroarch_hdmi.cfg /opt/retropie/configs/ngpc/retroarch.cfg > /dev/null
cp /opt/retropie/configs/wonderswan/retroarch_hdmi.cfg /opt/retropie/configs/wonderswan/retroarch.cfg > /dev/null
cp /opt/retropie/configs/wonderswancolor/retroarch_hdmi.cfg /opt/retropie/configs/wonderswancolor/retroarch.cfg > /dev/null
exit 1