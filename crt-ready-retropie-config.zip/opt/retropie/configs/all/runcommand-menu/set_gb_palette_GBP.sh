cp /home/pi/RetroPie/BIOS/palettes/GBP.pal /home/pi/RetroPie/BIOS/palettes/default.pal > /dev/null
exit 1