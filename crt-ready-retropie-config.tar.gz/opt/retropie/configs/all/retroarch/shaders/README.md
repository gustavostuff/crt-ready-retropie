#common-shaders

GLSL shaders from https://github.com/libretro/common-shaders.git, https://github.com/TheMaister/Emulator-Shader-Pack.git and https://github.com/gigaherz/lcd3x.git converted with cg2glsl.py. It is not possible to convert cg/cgp on the fly on arm platforms because
there is no nvidia-cg-toolkit package.